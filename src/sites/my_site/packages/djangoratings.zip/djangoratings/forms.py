from django import forms

__all__ = ('RatingField',)

class RatingField(forms.ChoiceField):
    pass